<footer class="footer">
        <p>&copy; 2024 PreeSoft. All rights reserved.</p>
    </footer>