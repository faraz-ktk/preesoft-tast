


<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="tab-pane fade show active" role="tabpanel" aria-labelledby="pills-news-tab">
    <div class="container-fluid">
        <h2 class="mb-3 font-weight-bold">Users</h2>
        <p>Lorem ipsum dolor sit amet, </p>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Projects\preesoft-task\resources\views/pages/users.blade.php ENDPATH**/ ?>