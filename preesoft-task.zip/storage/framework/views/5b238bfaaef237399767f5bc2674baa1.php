

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<h2>Login</h2>
<form method="POST" action="<?php echo e(route('login.post')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="username">Username</label>
        <input type="email" class="form-control" id="username" name="email" placeholder="email" required>
    </div>
    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password"
            required>
    </div>
    <button type="submit" class="btn btn-primary btn-block">Login</button>
</form>
<div class="signup-prompt mt-3">
    <p>Don't have an account? <a href="<?php echo e(route('register')); ?>">Sign up</a></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Projects\preesoft-task\resources\views/auth/login.blade.php ENDPATH**/ ?>