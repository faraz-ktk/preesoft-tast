

<?php $__env->startSection('title', 'Your Posts'); ?>

<?php $__env->startSection('content'); ?>
<div class="tab-pane fade show active" id="pills-company" role="tabpanel" aria-labelledby="pills-company-tab">
    <div class="container-fluid">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="header-row">
            <h2 class="font-weight-bold">Your Posts</h2>
            <button class="btn btn-custom" data-toggle="modal" data-target="#addPostModal">Add Post</button>
        </div>
        <table id="postsTable" class="table table-bordered">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Body</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr id="postRow-<?php echo e($post->id); ?>" data-id="<?php echo e($post->id); ?>">
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->body); ?></td>
                        <td>
                        <button class="btn btn-info btn-sm" onclick="openEditModal(<?php echo e($post->id); ?>, '<?php echo e($post->title); ?>', '<?php echo e($post->body); ?>')">Edit</button>
                        <button class="btn btn-danger btn-sm deletePostBtn" data-id="<?php echo e($post->id); ?>">Delete</button>
                        </td>
                    </tr>
                    <tr id="noPostsRow" style="display: none;">
                        <td colspan="4" class="text-center">No posts available</td>
                    </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr id="noPostsRow" style="display: bock;">
                        <td colspan="4" class="text-center">No posts available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Projects\preesoft-task\resources\views/pages/yourposts.blade.php ENDPATH**/ ?>