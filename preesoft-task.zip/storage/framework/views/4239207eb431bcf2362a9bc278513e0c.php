

<?php $__env->startSection('title', 'Feeds'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <h2 class="mb-4 font-weight-bold">Feeds</h2>
    
    <!-- Check if there are posts -->
    <?php if($posts->isEmpty()): ?>
        <div class="" role="alert">
        <div colspan="3" class="text-center">NO Post Found</div>
        </div>
    <?php else: ?>
        <div id="posts">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="post mb-4 p-3 border rounded">
                    <header class="mb-3">
                        <h3><?php echo e($post->title); ?></h3>
                        <div class="text-muted">Posted by: <?php echo e($post->user->name); ?></div>
                    </header>
                    <p><?php echo e($post->body); ?></p>
                    <button class="btn btn-info btn-sm toggle-comments-btn" onclick="toggleComments('<?php echo e($post->id); ?>')">
                        Show Comments
                    </button>
                    <div class="comments d-none mt-3" id="post<?php echo e($post->id); ?>">
                        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment mb-3 p-2 border rounded">
                                <div class="comment-header mb-1">
                                    <strong><?php echo e($comment->user->name ?? 'Anonymous'); ?></strong>
                                </div>
                                <p><?php echo e($comment->comment); ?></p>
                                <button class="btn btn-link like-btn" onclick="toggleLike(<?php echo e($comment->id); ?>, this)">
                                    <?php if($comment->user_liked): ?>
                                        <span class="text-danger">Unlike</span>
                                    <?php else: ?>
                                        <span class="text-success">Like</span>
                                    <?php endif; ?>
                                    <span class="like-count">(<?php echo e($comment->likes_count); ?>)</span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="comment-input mt-3">
                            <input type="text" class="form-control" placeholder="Add a comment..." id="comment-input-<?php echo e($post->id); ?>">
                            <button class="btn btn-primary mt-2" onclick="submitComment('<?php echo e($post->id); ?>')">Send</button>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Projects\preesoft-task\resources\views/pages/feeds.blade.php ENDPATH**/ ?>