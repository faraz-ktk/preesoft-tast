

<?php $__env->startSection('title', 'Your Posts'); ?>

<?php $__env->startSection('content'); ?>
<div class="tab-pane fade show active" id="pills-company" role="tabpanel" aria-labelledby="pills-company-tab">
    <div class="container-fluid">
        <div class="header-row">
            <h2 class="font-weight-bold">Your Posts</h2>
            <button class="btn btn-custom" data-toggle="modal" data-target="#addPostModal">Add Post</button>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Body</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Post 1</td>
                    <td>This is the body of Post 1</td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="editPost(1)">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deletePost(1)">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Post 2</td>
                    <td>This is the body of Post 2</td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="editPost(2)">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deletePost(2)">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Post 3</td>
                    <td>This is the body of Post 3</td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="editPost(3)">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deletePost(3)">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Post 4</td>
                    <td>This is the body of Post 4</td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="editPost(4)">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deletePost(4)">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Post 5</td>
                    <td>This is the body of Post 5</td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="editPost(5)">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deletePost(5)">Delete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Projects\preesoft-task\resources\views/pages/userPost.blade.php ENDPATH**/ ?>