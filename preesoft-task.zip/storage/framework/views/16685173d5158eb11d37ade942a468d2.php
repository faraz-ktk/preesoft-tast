<footer class="footer">
        <p>&copy; 2024 PreeSoft. All rights reserved.</p>
    </footer><?php /**PATH D:\Work\Projects\preesoft-task\resources\views/partials/footer.blade.php ENDPATH**/ ?>